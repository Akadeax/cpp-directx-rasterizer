#pragma once
struct Vertex_PosCol
{
	dae::Vector3 position;
	dae::Vector2 uv;
	dae::Vector3 normal;
	dae::Vector3 tangent;
};
